import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-stocks',
  templateUrl: './add-stocks.component.html',
  styleUrls: ['./add-stocks.component.css']
})
export class AddStocksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
