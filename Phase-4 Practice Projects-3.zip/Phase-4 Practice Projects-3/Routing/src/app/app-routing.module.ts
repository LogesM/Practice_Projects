import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutUsComponent } from './about-us/about-us.component';
import { AddStocksComponent } from './add-stocks/add-stocks.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { LoginComponent } from './login/login.component';
import { MarketStatusComponent } from './market-status/market-status.component';
import { SignupComponent } from './signup/signup.component';
import { StocksUpdateComponent } from './stocks-update/stocks-update.component';

//we have to write navigation rules
//http://localhost:4200
const routes: Routes = [
  {path : "aboutus",component:AboutUsComponent},
  {path : "contactus",component:ContactUsComponent},
  {path : "dashboard",component:DashboardComponent},
  {path : "feedback", component:FeedbackComponent},
  {path : "login" , component:LoginComponent},
  {path : "login/signup",component:SignupComponent},
  {path : "login/signup/signin",component:LoginComponent},
  {path : "stocks-update",component: StocksUpdateComponent},
  {path : "dashboard/stocks-update",component:StocksUpdateComponent},
  {path : "dashboard/market-status",component:MarketStatusComponent},
  {path : "dashboard/add-stocks",component:AddStocksComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
