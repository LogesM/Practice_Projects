import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocks-update',
  templateUrl: './stocks-update.component.html',
  styleUrls: ['./stocks-update.component.css']
})
export class StocksUpdateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
