import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-status',
  templateUrl: './market-status.component.html',
  styleUrls: ['./market-status.component.css']
})
export class MarketStatusComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
