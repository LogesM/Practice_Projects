import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
@Component({
  selector: 'app-structure-directive',
  templateUrl: './structure-directive.component.html',
  styleUrls: ['./structure-directive.component.css']
})
export class StructureDirectiveComponent implements OnInit {
  f1:boolean = true;
  f2:boolean = false;
  f3:boolean = false;
  b1:string = "show";
  f4:boolean = false;

  num1:number[] = [10,20,30,40,50];
  names:string[] = ["Ravi","Kumar","Loges","Ajay","Vijay"]

  employees:Array<Employee>=[];  //array object

  constructor() { }

  //it is life cycle function or method which will get call automatically after constructor.
  //This function call only once which is use to do some initilalization

  ngOnInit(): void {
    //class style
    //let emp1 = new Employee(1,"Loges",20000);
    //let emp2 = new Employee(2,"Kumar",12000);
    //let emp3 = new Employee(3,"Rahul",10000);
    //this.employees.push(emp1);
    //this.employees.push(emp2);
    //this.employees.push(emp3);

    //OR
    //interface style
    let emp1:Employee = {id:1,name:"Loges",salary:20000}
    let emp2:Employee = {id:2,name:"Kumar",salary:12000}
    let emp3:Employee = {id:3,name:"Rahul",salary:10000}
    this.employees.push(emp1);
    this.employees.push(emp2);
    this.employees.push(emp3);
  }

  addEmployeeDetails(idRef:any,nameRef:any,salaryRef:any){
    let idValue = idRef.value;
    let nameValue = nameRef.value;
    let salaryValue = salaryRef.value;
    let emp:Employee={id:idValue,name:nameValue,salary:salaryValue};//using interface so this type or using class use new
    this.employees.push(emp);
    idRef.value="";
    nameRef.value="";
    salaryRef.value="";
  }
  
  changeValue(){
    this.f3 = true;
  }

  toggle(){
    if(this.f4){
      this.f4 = false;
      this.b1 = "show"
    }else{
      this.f4 = true;
      this.b1 = "hide"
    }
  }

}
