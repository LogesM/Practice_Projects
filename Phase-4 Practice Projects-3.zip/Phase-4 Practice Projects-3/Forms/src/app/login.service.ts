import { Injectable } from "@angular/core";

@Injectable()                   //this annotation we write on service class
export class LoginService{
    checkUserDetails(login:any):string{
        if(login.email == "raj@gmail.com" && login.pass == "123"){
            return "Successfully Login";
          }else{
            return  "Failure try once again";
          }
    }
}