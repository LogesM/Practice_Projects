package com.service;

import java.util.List;

import com.bean.Classes;

import com.dao.ClassesDao;

public class ClassesService {
	ClassesDao cd = new ClassesDao();
	
	 public String storeClassesDetails(Classes classes) {
	        if(cd.storeClasses(classes)>0) {
	            return "Class details stored successfully";
	        }else {
	            return "Class details didn't store";
	        }
	    }
	 public List<Classes> findAllClasses() {
	        return cd.findAllClasses();
	    }

}
