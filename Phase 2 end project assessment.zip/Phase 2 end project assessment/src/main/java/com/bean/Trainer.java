package com.bean;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
@Entity
public class Trainer {
@Id
private int tid;
private String tname;
private String subject1;
private String subject2;
@OneToMany
@JoinColumn(name = "tsid")
private List<Student> listOfStd;
public int getTid() {
	return tid;
}
public void setTid(int tid) {
	this.tid = tid;
}
public String getTname() {
	return tname;
}
public void setTname(String tname) {
	this.tname = tname;
}
public String getSubject1() {
	return subject1;
}
public void setSubject1(String subject1) {
	this.subject1 = subject1;
}
public String getSubject2() {
	return subject2;
}
public void setSubject2(String subject2) {
	this.subject2 = subject2;
}

public List<Student> getListOfStd() {
	return listOfStd;
}
public void setListOfStd(List<Student> listOfStd) {
	this.listOfStd = listOfStd;
}

}
