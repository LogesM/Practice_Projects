package com.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Classes {
	@Id
	private int cid;
	private String trname1;
	private String trname2;
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getTrname1() {
		return trname1;
	}
	public void setTrname1(String trname1) {
		this.trname1 = trname1;
	}
	public String getTrname2() {
		return trname2;
	}
	public void setTrname2(String trname2) {
		this.trname2 = trname2;
	}
	@Override
	public String toString() {
		return "Classes [cid=" + cid + ", trname1=" + trname1 + ", trname2=" + trname2 + "]";
	}
	

}
