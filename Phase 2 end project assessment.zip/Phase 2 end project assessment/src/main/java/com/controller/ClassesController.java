package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Classes;
import com.service.ClassesService;

/**
 * Servlet implementation class ClassesController
 */
public class ClassesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClassesController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		ClassesService cs = new ClassesService();
		List<Classes> listOfClasses = cs.findAllClasses();
		HttpSession hs = request.getSession();
		hs.setAttribute("listOfClasses",listOfClasses);
		response.sendRedirect("viewClasses.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		int cid = Integer.parseInt(request.getParameter("cid"));
		String trname1 = request.getParameter("trname1");
		String trname2 = request.getParameter("trname2");
		
		Classes c = new Classes();
		c.setCid(cid);
		c.setTrname1(trname1);
		c.setTrname2(trname2);
		
		ClassesService cs = new ClassesService();
		String res = cs.storeClassesDetails(c);
		out.print(res);
		RequestDispatcher rd = request.getRequestDispatcher("storeClasses.jsp");
		rd.include(request, response);
	}

}
