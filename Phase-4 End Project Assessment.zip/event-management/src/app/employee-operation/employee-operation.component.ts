import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { FormGroup,FormControl} from '@angular/forms';

@Component({
  selector: 'app-employee-operation',
  templateUrl: './employee-operation.component.html',
  styleUrls: ['./employee-operation.component.css']
})
export class EmployeeOperationComponent implements OnInit {

  employee:any;

  constructor(public router : Router,public es : EmployeeService) { }

  employeeRef = new FormGroup({
    id : new FormControl(),
    ename: new FormControl(),
    salary: new FormControl()
  })

  ngOnInit(): void {
    let obj = sessionStorage.getItem("employeeInfo");
    if(obj != null){
      this.employee = JSON.parse(obj);
    }
  }

  viewAll(){
    this.router.navigate(["employee"]);
  }

  deleteEmployee(id:any){
    this.es.deleteEmployee(id).subscribe({
      next:(result:any)=>console.log(result),
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })
  }

  updateEmpDetails(){
    let employee = this.employeeRef.value;
    let id = this.employeeRef.value.id;
    this.es.updateEmp(id,employee).subscribe({
      next:(data:any)=>this.employee=data,
      error:(error:any)=>console.log(error),
      complete:()=>this.viewAll()
    })
  }

}
