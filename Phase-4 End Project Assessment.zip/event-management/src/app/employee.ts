//this class must be map to json data
//retrive from json-server or backend technology spring boot
export class Employee {
    constructor(public id:number,public ename:string,public salary:number){}
}
