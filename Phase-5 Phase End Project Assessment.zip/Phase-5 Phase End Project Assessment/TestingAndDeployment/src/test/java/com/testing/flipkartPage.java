package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
public class flipkartPage {
	WebDriver wd;
  @Test
  public void flipkart() {
	  wd.get("https://www.flipkart.com/");
	  
      wd.get("https://www.flipkart.com/mobile-phones-big-diwali-sale22-987gh-87uk-store?fm=neo%2Fmerchandising&iid=M_798e1c8a-2b93-43df-88df-1f2810e72b2a_1_ZTJ2HI685DLY_MC.34C7KPSH6R94&otracker=hp_rich_navigation_2_1.navigationCard.RICH_NAVIGATION_Mobiles%2B%2526%2BTablets_34C7KPSH6R94&otracker1=hp_rich_navigation_PINNED_neo%2Fmerchandising_NA_NAV_EXPANDABLE_navigationCard_cc_2_L0_view-all&cid=34C7KPSH6R94");
	  wd.manage().window().maximize();
	  System.out.println("Mobile category enter done..\n");
	  try {
		  Thread.sleep(7000);
	  }catch(InterruptedException e) {
		  e.printStackTrace();
	  }
	  wd.findElement(By.name("q")).sendKeys("iphone 13"+ Keys.ENTER);
	  System.out.println("Product Available");
	  
	  try {
		  Thread.sleep(8000);
	  }catch(InterruptedException e) {
		  e.printStackTrace();
	  }
	 WebElement findProd = wd.findElement(By.className("_1fQZEK"));
	 findProd.sendKeys(Keys.ENTER);
	 System.out.println("Product selected successfully...\n");
	 
	 
	 try {
		  Thread.sleep(3000);
	  }catch(InterruptedException e) {
		  e.printStackTrace();
	  }

     
	 JavascriptExecutor js = (JavascriptExecutor)wd;
	 js.executeScript("window.scrollBy(0,10000)","");
	 System.out.println("Scroll down success..\n");
	 
	 try {
		  Thread.sleep(3000);
	  }catch(InterruptedException e) {
		  e.printStackTrace();
	  }
	 js.executeScript("window.scrollBy(0,-10000)","");
	 System.out.println("Scroll Up success..\n");
	 
	 
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver","C:\\Phase -5\\chromedriver_win32\\chromedriver.exe");
      wd = new ChromeDriver();

  }

  @AfterMethod
  public void afterMethod() {
	 // wd.close();
  }

}
