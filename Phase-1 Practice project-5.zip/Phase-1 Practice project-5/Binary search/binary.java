import java.util.Scanner;
class binary{  
 public static void search(int arr[], int first, int last, int key){ 
	 
   int mid = (first + last)/2; 
   
   while( first <= last ){  
      if ( arr[mid] < key ){  
        first = mid + 1;     
      }
      else if ( arr[mid] == key ){  
        System.out.println("Element is found on the index : " + mid);  
        break;  
      }
      else{  
         last = mid - 1;  
      }  
      mid = (first + last)/2;  
   }  
   if ( first > last ){  
      System.out.println("Element not found.....");  
   }  
 }  
 public static void main(String args[]){  
	 Scanner sc = new Scanner(System.in);
        int arr[] = {11,22,33,44,55,66,77,88,99,00}; 
        System.out.println("Enter the key value to find : ");
        int key = sc.nextInt();
        int last=arr.length-1;  
        search(arr,0,last,key);     
 }  
}  
