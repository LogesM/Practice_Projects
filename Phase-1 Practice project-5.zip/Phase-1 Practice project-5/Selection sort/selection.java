
public class selection {  
    public static void sort(int[] arr){  
    	
        for (int i = 0; i < arr.length - 1; i++)  
        {  
            int x = i;  
            
            for (int j = i + 1; j < arr.length; j++){  
                if (arr[j] < arr[x]){  
                    x = j;
                }  
            }  
            
            int temp = arr[x];   
            arr[x] = arr[i];  
            arr[i] = temp;  
        }  
    }       
    public static void main(String a[]){  
    	
        int[] arr = {67,23,11,54,65,78,0,43,46};  
  
        sort(arr);
         
        System.out.println("Selection Sort of pre-defined array is : ");  
        
        for(int i:arr){  
            System.out.print(i + " ");  
        }  
    }  
}  