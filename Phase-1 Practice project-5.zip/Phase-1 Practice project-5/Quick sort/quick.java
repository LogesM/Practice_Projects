import java.util.Arrays;

class Quick_sort {

  static int sorting(int array[], int low, int high) {

    int pivot = array[high];
    int i = (low - 1);

    for (int j = low; j < high; j++) {
      if (array[j] <= pivot) {
        i++;
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
      }
    }

    int temp = array[i + 1];
    array[i + 1] = array[high];
    array[high] = temp;
    return (i + 1);
  }

  static void sort(int array[], int low, int high) {
    if (low < high) {

      int x = sorting(array, low, high);
 
      sort(array, low, x - 1);

      sort(array, x + 1, high);
    }
  }
}

class quick {
  public static void main(String args[]) {

    int[] element = {4,2,9,4,1,7,0};
   

    int size = element.length;

    Quick_sort.sort(element, 0, size - 1);

    System.out.println("Quick sort is : ");
    System.out.println(Arrays.toString(element));
  }
}
