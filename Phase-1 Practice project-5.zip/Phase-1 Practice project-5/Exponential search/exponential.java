import java.util.Arrays;
import java.util.Scanner;
class exponential
{
    static int search(int arr[], int a , int b)
    {
        if (arr[0] == b)
            return 0;

        int i = 1;
        while (i < a && arr[i] <= b) {
            i = i*2;
        }   
        return Arrays.binarySearch(arr, i/2, Math.min(i, a-1), b);
    }
    public static void main(String args[])
    {
    	Scanner sc = new Scanner(System.in);
        int arr[] = {23,42,46,765,22,15,0,1,2,32};
        System.out.println("Enter the element you want to search : ");
        int key = sc.nextInt();
        int result = search(arr,arr.length, key);
        if(result < 0) {
        	System.out.println("Element not available.... ");
        }
        else {
        	System.out.println("Element available on the position :  "+result);
        }
        sc.close();
    }
}