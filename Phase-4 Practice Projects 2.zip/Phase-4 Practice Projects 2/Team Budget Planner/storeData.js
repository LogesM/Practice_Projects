var empInfo;
function addData(){
    var nameValule1 = document.getElementById("clientName").value;
    var nameValule2 = document.getElementById("projectName").value;
    var budgetValue = document.getElementById("budget").value

    var obj = sessionStorage.getItem("obj");
    let emp = {clientName:nameValule1,projectName:nameValule2,budget:budgetValue};
    if(obj==null){
        empInfo = new Array();
        empInfo.push(emp);
        sessionStorage.setItem("obj",JSON.stringify(empInfo));
    }else {
        obj = JSON.parse(obj);
        obj.push(emp);
        sessionStorage.setItem("obj",JSON.stringify(obj));
    }
    document.getElementById("clientName").value=""
    document.getElementById("projectName").value=""
    document.getElementById("budget").value=""
    document.getElementById("out").innerHTML="Data Added.."
}