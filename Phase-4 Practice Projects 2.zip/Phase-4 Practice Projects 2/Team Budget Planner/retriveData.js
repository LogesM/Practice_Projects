function retriveData(){
    var obj = sessionStorage.getItem("obj");
    if(obj==null){
        document.getElementById("out").innerHTML="Record not present"
    }else {
        let empData = JSON.parse(obj);
        for(let i =0;i<empData.length;i++){
            let pTag = document.createElement("p");
            let ptTagValue = document.createTextNode(" Client Name is "+empData[i].clientName+" --> Project Name is "+empData[i].projectName+" --> Budget is "+empData[i].budget);
            pTag.appendChild(ptTagValue);
            document.getElementById("result").appendChild(pTag);
        }
    }
}