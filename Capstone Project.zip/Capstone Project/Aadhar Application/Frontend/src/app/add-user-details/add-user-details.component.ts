import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { UserDetailsService } from '../user-details.service';
@Component({
  selector: 'app-add-user-details',
  templateUrl: './add-user-details.component.html',
  styleUrls: ['./add-user-details.component.css']
})
export class AddUserDetailsComponent implements OnInit {

  userDetailsRef = new FormGroup({
    name:new FormControl(),
    dob:new FormControl(),
    number:new FormControl(),
    address:new FormControl(),
    gender:new FormControl()
  })
  storeMsg : string = ""
  constructor(public u:UserDetailsService) { }

  ngOnInit(): void {
  }

  storeUserDetails(){
    let userDetails = this.userDetailsRef.value;
    this.u.storeUserDetails(userDetails).subscribe({
      next:(result:any)=>this.storeMsg=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })

    this.userDetailsRef.reset();
  }
}
