import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { UserDetails } from './user-details';

@Injectable({
  providedIn: 'root'
})
export class UserDetailsService {

  baseUrl:string = "http://localhost:9595/userDetails"
  constructor(public http:HttpClient) { }

  storeUserDetails(userDetails:any):Observable<string>{
    return this.http.post(this.baseUrl+"/storeUserDetails",userDetails,{responseType:"text"});
  }

  updateUserDetails(userDetails:any):Observable<string>{
    return this.http.patch(this.baseUrl+"/updateUserDetails",userDetails,{responseType:"text"});
  }

  findAllUserDetails():Observable<UserDetails[]>{
    return this.http.get<UserDetails[]>(this.baseUrl+"/findAllUserDetails");
  }

  findAllUserDetailsByName(name:string):Observable<UserDetails[]>{
    return this.http.get<UserDetails[]>(this.baseUrl+"/findUserDetailsByName/"+name);
  }

  findAllUserDetailsById(uid:number):Observable<string>{
    return this.http.get(this.baseUrl+"/findAllUserDetailsById/"+uid,{responseType:"text"});
  }

  deleteUserDetailsById(uid:number):Observable<string>{
    return this.http.delete(this.baseUrl+"/deleteUserDetails/"+uid,{responseType:"text"});
  }
}
