import { Component, OnInit } from '@angular/core';
import { UserDetails } from '../user-details';
import { UserDetailsService } from '../user-details.service';
@Component({
  selector: 'app-admin-user-details-retrive',
  templateUrl: './admin-user-details-retrive.component.html',
  styleUrls: ['./admin-user-details-retrive.component.css']
})
export class AdminUserDetailsRetriveComponent implements OnInit {


  userDetails:Array<UserDetails>=[];
  constructor(public u:UserDetailsService) { }

  ngOnInit(): void {
    this.findAllUserDetails();
  }
  flag:boolean = false;
  uid:number = 0;
  name:string = "";
  number:string = "";
  address:string ="";

  findAllUserDetails(){
    this.u.findAllUserDetails().subscribe({
      next:(result:any)=>this.userDetails=result,
      error:(error:any)=>console.log(error),
      complete:()=>console.log("completed")
    })
  }

  deleteUserDetails(uid:number){
    this.u.deleteUserDetailsById(uid).subscribe({
      next:(result:any)=>console.log(result),
      error:(error:any)=>console.log(error),
      complete:()=>{
        this.findAllUserDetails();
      } 
    })
  }

  updateUserDetails(userDetails:any){
    this.flag=true;
    this.uid = userDetails.uid;
    this.name = userDetails.name;
    this.number = userDetails.number;
    this.address = userDetails.address;
  }

  updateDataFromDb(){
    let userDetails = {uid:this.uid,name:this.name,number:this.number,address:this.address};
    this.u.updateUserDetails(userDetails).subscribe({
      next:(result:any)=>console.log(result),
      error:(error:any)=>console.log(error),
      complete:()=>{
        this.findAllUserDetails();
      } 
    })
    this.flag=false;
  }


}
