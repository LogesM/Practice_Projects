import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminUserDetailsRetriveComponent } from './admin-user-details-retrive.component';

describe('AdminUserDetailsRetriveComponent', () => {
  let component: AdminUserDetailsRetriveComponent;
  let fixture: ComponentFixture<AdminUserDetailsRetriveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminUserDetailsRetriveComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminUserDetailsRetriveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
