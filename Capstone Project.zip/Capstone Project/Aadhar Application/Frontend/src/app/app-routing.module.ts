import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { LoginComponent } from './login/login.component';
import { UserdashboardComponent } from './userdashboard/userdashboard.component';
import { SignupComponent } from './signup/signup.component';
import { AddUserDetailsComponent } from './add-user-details/add-user-details.component';
import { AdminUserDetailsRetriveComponent } from './admin-user-details-retrive/admin-user-details-retrive.component';
const routes: Routes = [
  {path:"login",component:LoginComponent},
  {path:"admindashboard",component:AdmindashboardComponent,children:[
    {path:"findAllUserDetails",component:AdminUserDetailsRetriveComponent}
  ]},
  {path:"userdashboard",component:UserdashboardComponent,children:[
    {path:"addUserDetails",component:AddUserDetailsComponent},
  ]},
  {path:"signUp",component:SignupComponent},
  {path:"",redirectTo:"login",pathMatch:"full"}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
