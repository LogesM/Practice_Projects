//map to entity class
export class UserDetails {
    constructor(public uid:number,
        public name:string,
        public dob:string,
        public number:string,
        public address:string,
        public gender:string){}
}
