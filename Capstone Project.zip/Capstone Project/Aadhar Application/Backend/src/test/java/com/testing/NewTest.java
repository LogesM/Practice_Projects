package com.testing;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
public class NewTest {
	WebDriver wd;
  @Test
  public void mAadhar() {
	  
	  wd.get("http://localhost:4200/login");
	  wd.manage().window().maximize();
	  WebElement emailidRef = wd.findElement(By.name("emailid"));
	  emailidRef.sendKeys("admin@gmail.com");
	  
	  WebElement passwordRef = wd.findElement(By.name("password"));
	  passwordRef.sendKeys("Admin@1234");
	  
	  WebElement typeRef = wd.findElement(By.className("btn"));
	  typeRef.sendKeys("admin");
	  WebElement submitRef = wd.findElement(By.className("btn"));
	  //submitRef.sendKeys(Keys.ENTER);
	  submitRef.submit();
	  wd.close();
	  
	  wd.get("http://localhost:4200/login");
	  wd.manage().window().maximize();
	  WebElement emailiduserRef = wd.findElement(By.name("emailid"));
	  emailiduserRef.sendKeys("kumaresan@gmail.com");
	  
	  WebElement passworduserRef = wd.findElement(By.name("password"));
	  passworduserRef.sendKeys("kumar123456");
	  
	  WebElement typeuserRef = wd.findElement(By.className("btn"));
	  typeuserRef.sendKeys("admin");
	  WebElement submituserRef = wd.findElement(By.className("btn"));
	  //submitRef.sendKeys(Keys.ENTER);
	  submituserRef.submit();
	  
  }
  @BeforeMethod
  public void beforeMethod() {
	  System.setProperty("webdriver.chrome.driver","C:\\Users\\Logeswaran M\\Desktop\\Capstone Project\\Backend\\chromedriver_win32\\chromedriver.exe");
		 wd = new ChromeDriver();
  }

  @AfterMethod
  public void afterMethod() {
  }

}
