package com.mAadhar.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mAadhar.bean.UserDetails;
import com.mAadhar.service.UserDetailsService;

@RestController
@RequestMapping("userDetails")
@CrossOrigin
public class UserDetailsController {
	
	@Autowired
	UserDetailsService userDetailsService;
	
	@PostMapping(value = "storeUserDetails", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String storeUserDetails(@RequestBody UserDetails userDetails) {
		return userDetailsService.storeUserDetails(userDetails);
	}
	
	@PatchMapping(value = "updateUserDetails", consumes = MediaType.APPLICATION_JSON_VALUE)
	public String updateUserDetails(@RequestBody UserDetails userDetails) {
		return userDetailsService.updateUserDetails(userDetails);
	}
	
	@GetMapping(value = "findAllUserDetails", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UserDetails> getAllUserDetails(){
		return userDetailsService.getAllUserDetails();
	}
	
	@GetMapping(value = "findUserDetailsByName/{name}", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<UserDetails> findUserDetailsByName(@PathVariable("name") String name){
		return userDetailsService.findUserDetailsByName(name);
	}
	
	@GetMapping(value = "findAllUserDetailsById/{uid}")
	public String findUserDetailsById(@PathVariable("uid") int uid) {
		return userDetailsService.findUserDetailsById(uid);
	}
	
	@DeleteMapping(value = "deleteUserDetails/{uid}")
	public String deleteUserDetailsUsingId(@PathVariable("uid") int uid) {
		return userDetailsService.deleteUserDetails(uid);
	}

}
