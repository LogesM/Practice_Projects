package com.mAadhar.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mAadhar.bean.UserDetails;
import com.mAadhar.repository.UserDetailsRepository;

@Service
public class UserDetailsService {
	@Autowired
	UserDetailsRepository userDetailsRepository;
	
	public String storeUserDetails(UserDetails userDetails) {
		userDetailsRepository.save(userDetails);
		return "User Details Stored Successfully";
	}
	
	public List<UserDetails> getAllUserDetails(){
		return userDetailsRepository.findAll();
	}
	
	public String findUserDetailsById(int uid) {
		Optional<UserDetails> result = userDetailsRepository.findById(uid);
		if(result.isPresent()) {
			UserDetails u = result.get();
			return u.toString();
		}else {
			return "User Details not present";
		}
	}
	
	public List<UserDetails> findUserDetailsByName(String name){
		return userDetailsRepository.findUserDetailsByName(name);
	}
	
	public String deleteUserDetails(int uid) {
		Optional<UserDetails> result = userDetailsRepository.findById(uid);
		if(result.isPresent()) {
			UserDetails u = result.get();
			userDetailsRepository.delete(u);
			return "User Details deleted successfully";
		}else {
			return "User Details not present";
		}
	}
	
	public String updateUserDetails(UserDetails userDetails) {
		Optional<UserDetails> result = userDetailsRepository.findById(userDetails.getUid());
		if(result.isPresent()) {
			UserDetails u = result.get();
			u.setName(userDetails.getName());
			u.setNumber(userDetails.getNumber());
			u.setAddress(userDetails.getAddress());
			userDetailsRepository.saveAndFlush(u);
			return "User Details updated successfully";
		}else {
			return "User Details not present";
		}
	}

}
