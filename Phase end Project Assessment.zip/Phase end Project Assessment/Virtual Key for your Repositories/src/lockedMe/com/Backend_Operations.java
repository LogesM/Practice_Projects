package lockedMe.com;

import java.util.Scanner;
import java.util.List;

public class Backend_Operations {

	public static void menu1() {
		boolean process = true;
		Scanner sc = new Scanner(System.in);
		do {
			try {
				 Menu_Operation.MainMenu();
				 int num = sc.nextInt();
				 
				 switch(num){
				 case 1:
					 Backend_Operations.menu2();
					 break;
				 case 2:
					 File_Operations.displayFiles("main");
					 break;
				 case 3:
					 System.out.println("Program Exited...");
					 process = false;
					 sc.close();
					 System.exit(0);
					 break;
				 default:
					 System.out.println("  Please enter correct options....");
				 }
				 }catch(Exception e) {
					 System.out.println(e.getClass().getName());
					 menu1();
			}
		}while(process == true);
	}
	public static void menu2() {
		boolean process = true;
		Scanner sc = new Scanner(System.in);
		do {
			try {
				Menu_Operation.FileMenu();
				File_Operations.createfolder("main");
				int num = sc.nextInt();
				
				switch(num) {
				case 1:
					System.out.println("Enter the file name to add on the folder");
					String Fileadd = sc.next();
					File_Operations.createFile(Fileadd,sc);
					break;
					
				case 2:
					System.out.println("Enter the file name to delete from the folder");
					String Filedelete = sc.next();
					File_Operations.createfolder("main");
					List<String> Filedeletes = File_Operations.displayLocation(Filedelete,"main");
					
					System.out.println("Select which file to delete ?\nEnter 0 to delete items");
					
					int a = sc.nextInt();
					if(a != 0) {
						File_Operations.deleteFile(Filedeletes.get(a-1));
					}
					else {
						for(String path : Filedeletes) {
							File_Operations.deleteFile(path);
						}
					}
					break;
					
				case 3:
					System.out.println("Enter the file name to search on the folder");
					String fileName = sc.next();
					
					File_Operations.createfolder("main");
					File_Operations.displayLocation(fileName, "main");
					break;
					
				case 4:
					return;
					
				case 5:
					System.out.println(" Program exited....");
					process = false;
					sc.close();
					System.exit(0);
					
				default:
					System.out.println("\n--------Please enter correct option....");
				}
			}catch (Exception e) {
				System.out.println(e.getClass().getName());
				menu2();
			}
		}while(process == true);
	}
}
