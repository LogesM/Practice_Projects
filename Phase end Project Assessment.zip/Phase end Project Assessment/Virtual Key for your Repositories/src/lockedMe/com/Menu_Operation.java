package lockedMe.com;

public class Menu_Operation {
	public static void MainMenu() {
		System.out.println("1. Display the menu for file operations");
		System.out.println("2. Retrive the all files on main folder");
		System.out.println("3. Exit the program");

	}
	public static void FileMenu() {
		System.out.println("1. Add a file to the folder");
		System.out.println("2. Delete a file from the folder");
		System.out.println("3. Find a file from the folder");
		System.out.println("4. Back to the main menu");
		System.out.println("5. Exit the program");
	}

}
