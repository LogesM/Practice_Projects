package lockedMe.com;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class File_Operations {
	public static void createfolder(String name) {
		File file = new File(name);
		if(!file.exists()) {
			file.mkdirs();
		}
	}
	public static void displayFiles(String path) {
		File_Operations.createfolder("main");
		
		System.out.println("\nDisplay files and directory in ascending order\n");
		
		List<String> listNames = File_Operations.Listfilepath(path,0,new ArrayList<String>());
		
		System.out.println("All items are displayed in ascending order\n");
		Collections.sort(listNames);
		listNames.stream().forEach(System.out::println);
	}
	
	
	public static List<String>Listfilepath(String path,int count,List<String>Listnames){
		File filepath = new File(path);
		File[] file = filepath.listFiles();
		List<File> filelist = Arrays.asList(file);
		
		Collections.sort(filelist);
		
		if(file != null && file.length > 0) {
			for(File f : filelist) {
				System.out.println(" ".repeat(count * 2));
				
				if(f.isDirectory()) {
					System.out.println(" "+ f.getName());
					
					Listnames.add(f.getName());
				    Listfilepath(f.getAbsolutePath(),count + 1, Listnames);				
				}
				else {
					System.out.println("-> " + f.getName());
					Listnames.add(f.getName());
			   }
			
			}
		}
		else {
			System.out.print(" ".repeat(count * 2));
			System.out.println("-> Empty directory");
		}
		System.out.println();
		return Listnames;
	}
	
	
	public static void createFile(String Fileadd, Scanner sc) {
		File_Operations.createfolder("main");
		Path filepath = Paths.get("./main/"+ Fileadd);
		try {
			Files.createDirectories(filepath.getParent());
			Files.createFile(filepath);
			System.out.println(Fileadd+"\nFile is Successfully created....");
			System.out.println("Add some content on files? (Y/N) please enter");
			String option = sc.next().toLowerCase();
			sc.nextLine();
			
			if(option.equals("y")) {
				System.out.println("Please give the content and press enter\n");
				String content = sc.nextLine();
				Files.write(filepath, content.getBytes());
				System.out.println("\nContent written to file "+ Fileadd);
				System.out.println("Content can be read by using notepad\n\n");
			}
		}catch(IOException e) {
			System.out.println("File creation failed...."+Fileadd);
			System.out.println(e.getClass().getName());
		}
	}
	
	
	public static List<String>displayLocation(String fileName,String path){
		List<String>Listnames = new ArrayList<>();
		File_Operations.searchFile(path, fileName, Listnames);
		
		if(Listnames.isEmpty()) {
			System.out.println("\n\n-----The given file name could not find anything \"" + fileName + "\"-----\n\n");
		}
		else {
			System.out.println("\nFile is founded and the locations are given below : ");
			
			List<String>files = IntStream.range(0, Listnames.size()).mapToObj(index -> (index + 1) + ": "+ Listnames.get(index)).collect(Collectors.toList());
			files.forEach(System.out::println);
		}
		return Listnames;
	}
	
	
	public static void searchFile(String path, String fileName, List<String> Listnames) {
		File filepath = new File(path);
		File[] file = filepath.listFiles();
		List<File>filelist = Arrays.asList(file);
		
		if(file != null && file.length>0) {
			for(File f  : filelist) {
				if(f.getName().startsWith(fileName)) {
					Listnames.add(f.getAbsolutePath());
				}
				if(f.isDirectory()) {
					searchFile(f.getAbsolutePath(), fileName, Listnames);
				}
			}
		}
	}
	
	
	public static void deleteFile(String path) {
		File currentFile = new File(path);
		File[] file = currentFile.listFiles();
		
		if(file != null && file.length > 0) {
			for(File f : file) {
				String fileName = f.getName() + " at "+ f.getParent();
				if(f.isDirectory()) {
					deleteFile(f.getAbsolutePath());
				}
				if(f.delete()) {
					System.out.println(fileName + " - Successfully deleted....\n");
				}
				else {
					System.out.println("Delete failed "+ fileName);
				}
			}
		}
		
		String currentFilename = currentFile.getName()+" at "+currentFile.getParent();
		if(currentFile.delete()) {
			System.out.println(currentFilename+" - Successfully deleted\n");
		}
		else {
			System.out.println("\nDelete process failed" + currentFilename);
		}
	}

}
