package lockedMe.com;

public class Main_Menu {

	public static void main(String[] args) {
		
		System.out.println("\t-----------------------------\n\t Welcome to Lockers Pvt. Ltd.\n\t-----------------------------\n");
		System.out.println("\t   ***** LockedMe. com *****");
		System.out.println("      Developed by Logeswaran Mohanraj");
		System.out.println("\nThis applications are used to retrive, add, delete and modify the files from the main folder.");
		System.out.println("\n\nPlease you need give the correct file names on specific format and case sensitive....");
		System.out.println("\n\nSelect the options to perform the operations, they are given below");
		
		File_Operations.createfolder("main");
		Backend_Operations.menu1();
		
	}
	

}
