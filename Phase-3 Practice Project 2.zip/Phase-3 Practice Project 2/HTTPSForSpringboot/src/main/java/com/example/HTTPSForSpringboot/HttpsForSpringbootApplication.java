package com.example.HTTPSForSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HttpsForSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(HttpsForSpringbootApplication.class, args);
	}

}
