package package2;


public class public2 {

	public void display() 
    { 
        System.out.println("Public Access Specifiers"); 
    } 
}