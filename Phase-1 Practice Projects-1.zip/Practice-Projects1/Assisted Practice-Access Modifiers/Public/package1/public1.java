package package1;
import package2.*;

public class public1 {

	public static void main(String[] args) {
		
		public2 obj = new public2();
		
        obj.display();  
		
	}
}