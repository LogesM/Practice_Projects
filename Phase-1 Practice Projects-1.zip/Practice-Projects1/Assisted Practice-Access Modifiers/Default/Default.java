
class object
{ 
  void display() 
     { 
         System.out.println(" Hello Everone....... \n This called default specifier..."); 
     } 
} 

public class Default {

	public static void main(String[] args) {
		//default
		System.out.println(" Welcome.... ");
		object obj = new object(); 		  
        obj.display(); 

	}
}