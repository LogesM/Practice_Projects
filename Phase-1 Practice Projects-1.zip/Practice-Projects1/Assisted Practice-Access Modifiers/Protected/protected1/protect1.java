package protected1;
import protected2.*;

public class protect1 extends protect2 {

	public static void main(String[] args) {
		
		protect1 obj = new protect1 ();   
		
	    obj.display();  
	}

}