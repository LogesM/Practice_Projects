package protected2;

public class protect2 {

	protected void display() 
    { 
        System.out.println("protected access specifier"); 
    } 
}