import java.io.File;
public class DeleteFile {

	public static void main(String[] args) {
		File fd = new File("E:\\File handling.txt");
		
		if(fd.delete()) {
			System.out.println("File is deleted...."+fd.getName()+"Successfully...");
		}
		else {
			System.out.println("Error occured..");
		}

	}

}
