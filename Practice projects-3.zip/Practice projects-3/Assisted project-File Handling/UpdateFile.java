import java.io.IOException;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
public class UpdateFile {
	
	public static void main(String[] args)throws IOException {
		Path filepath = Paths.get("E:\\File handling.txt");
		if(!Files.exists(filepath)) {
			Files.createFile(filepath);
			
		}
		Files.write(filepath, "\n Later we talk abou the append operation".getBytes(), StandardOpenOption.APPEND);
	}

}