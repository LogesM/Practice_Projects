package create;
import java.io.FileWriter;
import java.io.IOException;
public class WriteFile {

	public static void main(String[] args) {
		try {
			FileWriter fw = new FileWriter("E:\\File handling.txt");
			fw.write("In this method i will try to wite on my file...");
			fw.close();
			System.out.println("Successfully written");
		}catch(IOException e){
			System.out.println("An error...");
			e.printStackTrace();
		}
	}

}
