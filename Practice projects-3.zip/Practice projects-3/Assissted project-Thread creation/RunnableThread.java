package com;

public class RunnableThread implements Runnable{
	public void run() {
		System.out.println("This is Runnable thread....");
	}

	public static void main(String[] args) {
		RunnableThread obj = new RunnableThread();
		Thread obj1 = new Thread(obj);
		obj1.start();

	}

}
