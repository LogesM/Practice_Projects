class bike{
	public void speed() {
		System.out.println("60 km/hr");
	}
}
class honda extends bike{
	public void color() {
		System.out.println("black");
	}
}
class pulsar extends bike{
	public void speed() {
		System.out.println("90 km/hr");
	}
	public void color() {
		System.out.println("red");
	}
}
class tvs extends bike{
	public void color() {
		System.out.println("grey");
	}
	public void speed() {
		super.speed();
		System.out.println("20 km/hr");
	}
}
public class RunTime_poly {

	public static void main(String[] args) {
		honda hh=new honda();
		hh.color();
		hh.speed();
		pulsar pp=new pulsar();
		pp.color();
		pp.speed();
        tvs tt=new tvs();
        tt.color();
        tt.speed();
	}

}
