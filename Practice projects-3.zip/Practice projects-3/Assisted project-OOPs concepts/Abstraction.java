abstract class A{
	abstract void dis1();
}
class B extends A{
	void dis1() {
		System.out.println("A class dis1 method override by B class ");
	}
	void dis2() {
		System.out.println("B class dis2 method");
	}
}
public class Abstraction{
	public static void main(String args[]) {
		
		B obj2= new B();
		obj2.dis1();
		obj2.dis2();
		A obj3 = new B();
		obj3.dis1();
	}
}

