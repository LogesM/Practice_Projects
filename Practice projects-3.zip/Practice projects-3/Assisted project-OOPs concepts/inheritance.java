class Calculator {
   int z;	
   public void add(int a, int b) {
      z = a + b;
      System.out.println("The addition of two numbers:"+z);
   }
	
   public void Sub(int c, int d) {
      z = c - d;
      System.out.println("The subtraction of two numbers:"+z);
   }
}

public class inheritance extends Calculator {
   public void mul(int e, int f) {
      z = e * f;
      System.out.println("The multiplication of numbers:"+z);
   }
	
   public static void main(String args[]) {
      int num1 = 20, num2 = 10;
      inheritance demo = new inheritance();
      demo.add(num1, num2);
      demo.Sub(num1, num2);
      demo.mul(num1, num2);
   }
}

