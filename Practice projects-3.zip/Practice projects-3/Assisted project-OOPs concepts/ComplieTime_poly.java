
class operatio {
	public void area(int r) {
		double area = 3.142*r*r;
		System.out.println("Area of the circle : "+area);
	}
	public void area(int b,int h) {
		double area = 0.5*b*h;
	}
}
public class ComplieTime_poly{
	public static void main(String[] args) {
		operatio op = new operatio();
		op.area(4);
        op.area(10,12);
	}
}

