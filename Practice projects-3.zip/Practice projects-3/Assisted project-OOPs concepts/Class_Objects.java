class operation{
	void add() {
		int a=10;
		int b=10;
		System.out.println("Adding two Numbers: "+(a+b));
	}
}
public class Class_Objects {
	public static void main(String args[]) {
		operation obj = new operation();
		obj.add();
	}

}
