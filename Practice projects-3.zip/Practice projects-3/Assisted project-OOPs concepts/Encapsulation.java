class formula {

   int len;
   int bre;

   formula(int len, int bre) {
	  this.len = len;
      this.bre = bre;
   }
   public void Area() {
       int area = len * bre;
       System.out.println("Area: " + area);
   }
}

class Encapsulation {
    public static void main(String[] args) {
	   formula rec = new formula(8, 7);
	   rec.Area();
    }
}


