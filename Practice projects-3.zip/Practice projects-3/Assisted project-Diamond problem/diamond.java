interface A 
{  
   public default void display()   
   {  
      System.out.println("the display() method A....");  
   }  
}  
interface B  
{  
   public default void display()   
   {  
      System.out.println("the display() method B....");  
   }  
}  
public class diamond implements A, B
{  
   public void display()   
   {  
      A.super.display();  
      B.super.display();  
   }  
   public static void main(String args[])   
   {  
      diamond obj = new diamond();  
      obj.display();  
   }  
}  

