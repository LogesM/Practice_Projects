public class ExceptionHand {
	static void display1() throws Exception{
		int c=10/0;
		System.out.println("Display 1");
	}
	static void display2(){
		try {
		   display1();
		}catch(Exception e) {
			System.out.println("Display 2");
		}
	}
	public static void main(String[] args) {
		ExceptionHand obj = new ExceptionHand();
		obj.display2();
		int a=10;
		int b=5;
		System.out.println("Finally Keyword .....\n");
		try {
			if(a>b) {
				throw new Exception();
			}					
		}
		catch(Exception e) {
			System.out.println(e.toString());
		}
		finally {
			System.out.println("\tfinally block\n");
		}
	}

}
