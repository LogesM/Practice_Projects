
public class Throw {  
	public static void checkNum(int num) {  
	    if(num < 1) {  
	       throw new ArithmeticException("\n The number is negative, cannot calculate square");  
	    }  
	    else {  
	       System.out.println("Square of "+num+" is "+(num*num));  
	    }  
    }  
	public static void main(String[] args) {  
		System.out.println("Throw keyword ...\n");
	    Throw obj = new Throw();  
	     obj.checkNum(2);    
	}  
}  


