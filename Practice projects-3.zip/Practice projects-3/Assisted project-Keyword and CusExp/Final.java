
public class Final {
	public static void main(String[] args) {
		System.out.println("Finally Keyword .....\n");
		try {
			int result =10/0;
			System.out.println("\tNo exception\n");
		}
		catch(Exception e) {
			System.out.println("\tcatch block\n");
		}
		finally {
			System.out.println("\tfinally block\n");
		}
		System.out.println("\tNormal Statement\n");
	}

}
