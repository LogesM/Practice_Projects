
public class Throws {
 
	    public static int divide(int m, int n) throws ArithmeticException {  
	        int div = m / n;  
	        return div;  
	    }   
	    public static void main(String[] args) { 
	    	System.out.println("Throws keyword ...\n");
	        Throws obj = new Throws();  
	        try {  
	            System.out.println(obj.divide(45, 0));  
	        }  
	        catch (ArithmeticException e){  
	            System.out.println("This is not divided....");  
	        }  
	    }    

}
