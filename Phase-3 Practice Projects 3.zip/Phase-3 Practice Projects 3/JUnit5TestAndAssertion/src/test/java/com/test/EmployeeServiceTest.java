package com.test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.bean.Employee;
import com.service.EmployeeService;

class EmployeeServiceTest {

	@Test
	@DisplayName("Check user details testing")
	void testCheckUser() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		String result = es.checkUser("raj@gmail.com", "123");
		assertEquals("success",result);
		
		String result1 = es.checkUser("ram@gmail.com", "123");
		assertEquals("failure",result1);
	}

	@Test
	//@Disabled  // it is used for temporary disable use this annotation
	void testGetEmployee() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		Employee emp = es.getEmployee();
		assertNotNull(emp);
		assertEquals(1,emp.getId());
		assertEquals("Rajesh",emp.getName());
		assertEquals(12000,emp.getSalary());
	}

	@Test
	void testListOfEmployee() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		List<Employee>listOfEmp = es.listOfEmployee();
		assertEquals(2, listOfEmp.size());
	}

	@Test
	void testPassEmployeeObject() {
		//fail("Not yet implemented");
		EmployeeService es = new EmployeeService();
		Employee emp = new Employee();
		emp.setId(1);
		emp.setName("Rajesh");
		emp.setSalary(12000);
		float updatedSalary = es.passEmployeeObject(emp);
		assertEquals(12500,updatedSalary);
	}

}
