package test;
import org.junit.platform.suite.api.Suite;
import org.junit.platform.suite.api.SuiteDisplayName;
import org.junit.platform.suite.api.SelectPackages;

//@RunWith(Suite.class)
@Suite
@SelectPackages("com.test")
@SuiteDisplayName(value = "My all JUnit5 test files")
public class AllTests {

}
