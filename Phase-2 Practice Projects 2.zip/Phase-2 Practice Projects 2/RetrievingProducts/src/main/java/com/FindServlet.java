package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class FindServlet
 */
public class FindServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/myjavadb", "root", "Loges179@");
			Statement stmt = con.createStatement();
			PrintWriter pw = response.getWriter();
			
			String search = request.getParameter("search");
			
			if(search.isEmpty()) {
				pw.print("The given product ID is different. So please Try again");
				
			}
			else {
				String id = "select * from Ecommerce where product_id = "+search;
				ResultSet rs = stmt.executeQuery(id);
				if(rs.next()) {
					pw.println("ID is "+ rs.getInt("product_id") + " - Product name is " + rs.getString("product_name") + " - Price is " + rs.getInt("price"));
				}
				else {
					pw.print("There is no products in the list : "+ search + "Try again");
				}
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	}

}
