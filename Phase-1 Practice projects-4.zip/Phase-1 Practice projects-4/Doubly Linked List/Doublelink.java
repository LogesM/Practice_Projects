class Doublelink {
    static Node head;
    static class Node {
        int data;
        Node nextnode, prevnode;
        Node(int a)
        {
            data = a;
            nextnode = prevnode = null;
        }
    }
    void reverse()
    {
        Node temp = null;
        Node currentnode = head;
        while (currentnode != null) {
            temp = currentnode.prevnode;
            currentnode.prevnode = currentnode.nextnode;
            currentnode.nextnode = temp;
            currentnode = currentnode.prevnode;
        }
        if (temp != null) {
            head = temp.prevnode;
        }
    }
    void push(int a)
    {
        Node X = new Node(a);
        X.prevnode = null;
        X.nextnode = head;
        if (head != null) {
            head.prevnode =X;
        }
        head = X;
    }
    void print(Node node)
    {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.nextnode;
        }
    }  
    public static void main(String[] args)
    {
        Doublelink dl = new Doublelink();
        dl.push(43);
        dl.push(87);
        dl.push(12);
        dl.push(100);
        dl.push(93);
        System.out.println("The forward traverse elements:  ");
        dl.print(head);
  
        dl.reverse();
     
        System.out.println("\nThe reversed travese elements: ");
        dl.print(head);
    }
}