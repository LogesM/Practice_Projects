import java.util.LinkedList;
import java.util.Queue;
public class insert_removve {
public static void main(String[] args) {
        		Queue<String> Q = new LinkedList<>();
        		
                Q.add("Apple");
        		Q.add("Ball");
        		Q.add("Cat");
        		Q.add("Dog");
        		Q.add("Elephant");
        		
                System.out.println("Queue elements are : " + Q);
        		System.out.println("Head of the Queue : " + Q.peek());
        		
        		Q.remove();
        		
        		System.out.println("After removing Head of Queue : " + Q);
        		System.out.println("Size of the Queue is : " + Q.size());
    	}
}