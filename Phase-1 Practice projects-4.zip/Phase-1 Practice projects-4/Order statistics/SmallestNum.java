import java.util.Scanner;
class SmallestNum {
    static int small(int[] arr, int x, int y)
    {
        int c = 0;
        for (int i = 0; i < x; i++)
        {
            if (arr[i] > c)
                c = arr[i];
        }
        int[] count = new int[c + 1];
        int small = 0;
        for (int i = 0; i < x; i++)
        {
            count[arr[i]]++;
        }
        for (int n = 1; n <= c; n++)
        {
            if (count[n] > 0)
            {
                small += count[n];
            }
            if (small >= y)
            {
                return n;
            }
        }
        return -1;
    }
    public static void main(String[] args)
    {
    Scanner sc = new Scanner(System.in);
       System.out.println("Enter the length of the array : ");
       int a = sc.nextInt();
       int[] arr = new int[20];
       System.out.println("Enter the elements of the array : ");
       for(int i=0;i<a;i++) {
    	   arr[i] = sc.nextInt();
       }
       System.out.println("Enter the position of smallest number : ");
       int b = sc.nextInt();
       System.out.print(small(arr, a, b));
    }
}
