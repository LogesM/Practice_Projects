import java.util.Arrays;
public class Rotation {

	public static void main(String[] args) {
		Integer[] numbers = new Integer[] {1,2,3,4,5,6,7};
		Integer k =5;
		Integer j;
		while(k>0) {
			Integer lastElement = numbers[numbers.length - 1];
			for(j = numbers.length - 1; j>0;j--) {
				numbers[j] = numbers[j-1];
			}
			numbers[j] = lastElement;
			k--;
		}
		Arrays.stream(numbers).forEach(System.out::println);

	}

}
