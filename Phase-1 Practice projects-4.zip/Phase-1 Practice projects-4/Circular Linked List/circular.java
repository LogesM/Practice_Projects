
class Node 
{ 
    int data; 
    Node nextnode; 
    Node(int d) 
    { 
        data = d; 
        nextnode = null; 
    } 
}  
class circular
{ 
    Node head; 
    circular()   { 
    	head = null; 
    } 
    void insert(Node newnode) 
    { 
        Node currentnode = head; 
 
        if (currentnode == null) 
        { 
            newnode.nextnode = newnode; 
            head = newnode; 
  
        } 
        else if (currentnode.data >= newnode.data) 
        { 
            while (currentnode.nextnode != head) 
                currentnode = currentnode.nextnode; 
  
            currentnode.nextnode = newnode; 
            newnode.nextnode = head; 
            head = newnode; 
        } 
        else
        {  
            while (currentnode.nextnode != head && 
                   currentnode.nextnode.data < newnode.data) 
                currentnode = currentnode.nextnode; 
  
            newnode.nextnode = currentnode.nextnode; 
            currentnode.nextnode = newnode; 
        } 
    } 
    void print() 
    { 
        if (head != null) 
        { 
            Node temp = head; 
            do
            { 
                System.out.print(temp.data + " "); 
                temp = temp.nextnode; 
            }  while (temp != head); 
        } 
    } 
    public static void main(String[] args) 
    { 
        circular list = new circular(); 
        
        int arr[] = new int[] {10,9,7,8,5,2,4,3,6,1}; 

        Node temp = null; 
 
        for (int i = 0; i < 10; i++) 
        { 
            temp = new Node(arr[i]); 
            list.insert(temp); 
        } 
        list.print(); 
    } 
} 