
public class query
{ 
    static int a = 16;
    static int b = 100; 
    static long t[][] = new long[b][a + 1]; 
    static void x(int arr[], int n) 
    { 
        for (int i = 0; i < n; i++) {
            t[i][0] = arr[i]; 
        }   
        for (int j = 1; j <= a; j++) { 
            for (int i = 0; i <= n - (1 << j); i++) { 
                t[i][j] = t[i][j - 1] + t[i + (1 << (j - 1))][j - 1];
            }
        }   
    } 
    static long query (int p, int q) 
    {
        long ans = 0; 
        for (int j = a; j >= 0; j--){ 
            if (p + (1 << j) - 1 <= q){ 
                ans = ans + t[p][j];
                p += 1 << j; 
            } 
        } 
        return ans; 
    }
    public static void main(String args[]) 
    { 
        int arr[] = { 3, 7, 2, 5, 8, 9 }; 
        int n = arr.length; 
        x(arr, n); 
        System.out.println(query(0, 5)); 
        System.out.println(query(3, 5)); 
        System.out.println(query(2, 4)); 

    } 
}