package stack;
import java.util.Stack;
public class push_pop {
   public static void main (String args[]) {
      Stack s = new Stack(); 
      
      s.push("1");
      s.push("2");
      s.push("3");
      s.push("4");
      s.push("5");
      
      System.out.println("Stack elements : " + s);
      System.out.println("In Stack remove the last element : " + s.pop());
      
      System.out.println("After the removing the element : " + s);
      System.out.println("In Stack remove the last element : " + s.pop());
      
      System.out.println("After the removing the element : " + s);
   }
}