public class Singlylink
{ 
   Node head; 
   static class Node 
   { 
        int data; 
    	Node next; 
        Node(int d){ 
           	data = d; 
   			next = null; 
   		} 
    } 
    public static Singlylink insert(Singlylink list, int data) 
    { 
        		
        Node newnode = new Node(data); 
   		newnode.next = null;  
        if (list.head == null){ 
           list.head = newnode; 
       	} 
   		else 
        {  
   			Node last = list.head; 
            while (last.next != null){ 
                last = last.next; 
            } 
            last.next = newnode; 
       	} 
   		return list; 
   	} 
   	public static void print(Singlylink list) 
    {	 
   		Node currentNode = list.head; 
        System.out.print("LinkedList elements are : "); 
        while (currentNode != null) 
        {  
            System.out.print(currentNode.data + " ");  
            currentNode = currentNode.next; 
       	} 
  		System.out.println(); 
   	} 
    public static Singlylink delete(Singlylink list, int key) 
   	{ 
    	Node currNode = list.head, prev = null; 
        if (currNode != null && currNode.data == key) 
        { 
            list.head = currNode.next; 
            System.out.println(key + " found and deleted"); 
            return list; 
       	} 
        while (currNode != null && currNode.data != key) 
        { 
            prev = currNode; 
          	currNode = currNode.next; 
       	} 
  		if (currNode != null) 
        { 
            prev.next = currNode.next; 
            System.out.println(key + " found and deleted"); 
       	} 
        if (currNode == null) 
        { 
            System.out.println(key + " Key is not found"); 
       	} 
      	return list; 
    }  
    public static void main(String[] args) 
    { 
        Singlylink list = new Singlylink();  
        list = insert(list, 4); 
        list = insert(list, 32); 
       	list = insert(list, 2); 
       	list = insert(list, 53); 
       	list = insert(list, 43); 
       	list = insert(list, 65); 
       	list = insert(list, 34); 
       	list = insert(list, 43);         		
       	print(list); 
        		 
        delete(list, 4);         
        print(list); 
        		 
        delete(list, 53);         	 
        print(list); 
        		 
       	delete(list, 43);         	
        print(list); 
    	} 
} 
